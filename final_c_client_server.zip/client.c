// created by Jordon Zeigler 3/3/2021
// code referenced from Professor Girard
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifdef _WIN32
  #include <winsock2.h>
  #include <Ws2tcpip.h>
#else
  #include <sys/socket.h>
  #include <arpa/inet.h>
  #include <netdb.h> 
  #include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#pragma comment(lib, "Ws2_32.lib")

//#include <windows.h>
//#include <winsock2.h>
//#include <ws2tcpip.h>
//#include <iphlpapi.h>
#ifndef _WIN32
  #define SOCKET int
#endif

#define MAX 10

#define SA struct sockaddr
#define sock


// function intended to read input specifically from client
void readFromConnection(int incomingSocket, char* data)
{
    //declares a temporary string to store input along with
    // emptying it out with bzero
    char tmp[MAX+1];
    bzero(tmp,MAX+1);
    //declares count for later use
    int count = 0;

    // while loop to receive from other socket
    while (count != MAX)
    {
        int start = count;
        // controls how much is read from connection
        int maxRead = MAX - start;
        count += recv(incomingSocket,tmp,maxRead,0);
        
        //stores characters from tmp into data argument
        for (int x = start; x < count; x++)
        {
            data[x] = tmp[x-start];
        }
    }

    
}

//void print_reverse(char* reverse){
  //printf("%s\n", reverse);
//}
// designed for chat between client and server
void func(int sockfd)
{
    // stores output from other socket
    char buff[MAX];
    int n;
    // stores file name for later use, seconds stores it for reversing later
    char f[4] = "msg";
    char fr[4] = "msg";
    int len = strlen(f)-1;

        // reverses fr string so that it can access the file name with the reverse name as the initial file
        for(int i = 0; i < (len/2); i++) {
            fr[i] = f[(len-i)];
            fr[len-i] = f[i];
        }
    // opens both files up for reading and writing respectively
    FILE *fp = fopen(f, "r");
    FILE  *fp2 = fopen(fr, "a");
    
    // while loop to continuously read from connection
    while(1){
        // empties out buff string
        bzero(buff, sizeof(buff));

        // reads text from first file 
        if(fgets(buff, 11, (FILE*)fp) == 0){
          break;
        }
        
        // adds spaces onto the buff string if it isn't ten characters long
        if(strlen(buff) < MAX){
          for(int i = strlen(buff); i < MAX; i++){
            buff[i] = ' ';
            
          }
        }

        // adds \0 onto the end to ensure string can end correctly
        if(strlen(buff) > MAX)
        {
          buff[MAX] = '\0';
        }
      
        // sends string to server
        send(sockfd, buff, sizeof(buff), 0);
        
        // reads adjusted string from server
        readFromConnection(sockfd, buff);
        
        // writes results into second file
        fwrite(buff, 1, strlen(buff), fp2);
        
        
        

    }
    // closes both files
    fclose(fp);
    fclose(fp2);
    
}

int main(int argc, char * argv[])
{
    // declares ints for saving socket info
    int sockfd, connfd;
    // declares sockaddr_in variables for the server and client
    struct sockaddr_in servaddr, client;

    //socket creation note leftover from when it was originally being developed as cross platform 
    // rather than solely linux/unix
    #ifdef _WIN32
        //sockfd = sockInit();
    #endif
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
    
     // basic messages that convery if socket creation was successful
    if (sockfd == -1) 
    {
        printf("socket creation failed\n");
        exit(0);
    }
    else{
        printf("socket created\n");
    }
    // clears servaddr memory
    bzero(&servaddr, sizeof(servaddr));

    // assign IP and PORT
    int port = atoi(argv[2]);
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(port);

    // connect client socket to server socket
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0)
    {
        printf("connection with server failed\n");
        exit(0);
    }
    else
    {
        printf("connected to the server\n");
    }

    // function to initiate chat
    func(sockfd);
    //printf("function exited\n");
    // closes the soccket
    close(sockfd);
}