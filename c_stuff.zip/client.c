// created by Jordon Zeigler 3/3/2021
// code referenced from Professor Girard
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifdef _WIN32
  #include <winsock2.h>
  #include <Ws2tcpip.h>
#else
  #include <sys/socket.h>
  #include <arpa/inet.h>
  #include <netdb.h> 
  #include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#pragma comment(lib, "Ws2_32.lib")

//#include <windows.h>
//#include <winsock2.h>
//#include <ws2tcpip.h>
//#include <iphlpapi.h>
#ifndef _WIN32
  #define SOCKET int
#endif

#define MAX 10
//#define PORT 4446
#define SA struct sockaddr
#define sock
//#define bzero(b,len) (memset((b), '\0', (len)), (void) 0)


int sockInit(void)
{
  #ifdef _WIN32
    WSADATA wsa_data;
    return WSAStartup(MAKEWORD(1,1), &wsa_data);
  #else
    return 0;
  #endif
}

int sockQuit(void)
{
  #ifdef _WIN32
    return WSACleanup();
  #else
    return 0;
  #endif
}

int sockClose(sock soc)
{

  int status = 0;

  #ifdef _WIN32
    status = shutdown(soc, SD_BOTH);
    if (status == 0) { status = closesocket(soc); }
  #else
    status = shutdown(soc, SHUT_RDWR);
    if (status == 0) { status = close(soc); }
  #endif

  return status;

}

void readFromConnection(int incomingSocket, char* data)
{
    char tmp[MAX+1];
    bzero(tmp,MAX+1);
    int count = 0;

    while (count != MAX)
    {
        int start = count;
        int maxRead = MAX - start;
        count += recv(incomingSocket,tmp,maxRead,0);
        //printf("count: %d\n", count);
        if (count > start)
        {
            printf("%s\n", tmp);
        }
        for (int x = start; x < count; x++)
        {
            data[x] = tmp[x-start];
        }
    }

    
}

void print_reverse(char* reverse){
  printf("%s\n", reverse);
}
void func(int sockfd)
{
    //printf("in func\n");
    char buff[MAX];
    int n;
    //char c;
    FILE *fp = fopen("msg", "r");
    while(1){
        bzero(buff, sizeof(buff));
        //printf("Enter the string: ");
        //n = 0;
        //fgets(buff, 11, stdin);
        //printf("Enter the string : ");
        //n = 0;

        if(fgets(buff, 11, (FILE*)fp) == 0){
          break;
        }
        printf("%s\n", buff);
        /*for(int i = 0; i <= MAX; i++){
          if(c = getchar() == '\n'){
            break;
          }

          if(i == MAX){
              break;
          }
          else{
            buff[i] = c;
          }
        }*/
        //while ((buff[n++] = getchar()) != '\n' && n <= MAX)
        //    ;

        //scanf("%10s", buff);
        //while ((buff[n++] = getchar()) != '\n' && n <= MAX)
        //{
        //    ;
        //}
        //ADD IN PADDING
        if(strlen(buff) < MAX){
          //buff[strlen(buff) - 1] = '_';
          for(int i = strlen(buff); i < MAX; i++){
            buff[i] = '_';
            //strcat(buff,"_");
          }
        }
        if(strlen(buff) > MAX)
        {
          buff[MAX] = '\0';
        }
        //printf("Sent: %s\n", buff);
        //printf("length: %ld\n", strlen(buff));
        //printf("sent: %ld\n", strlen(buff));
        send(sockfd, buff, sizeof(buff), 0);
        //printf("right after text is sent\n");
        readFromConnection(sockfd, buff);


        //recv(sockfd, buff, MAX+1, 0);
        printf("%s\n", buff);
        
        

    }
    printf("hello\n");
    //send(sockfd, "exit", )
}

int main(int argc, char * argv[])
{
    int sockfd, connfd;
    struct sockaddr_in servaddr, client;

    //socket creation
    #ifdef _WIN32
        sockfd = sockInit();
    #endif
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
    
    printf("%d", sockfd);
    if (sockfd == -1) 
    {
        printf("socket creation failed\n");
        exit(0);
    }
    else{
        printf("socket created\n");
    }

    bzero(&servaddr, sizeof(servaddr));

    /*printf("please enter an IP address\n");
    char ip[16];
    scanf("%15s", ip);
    printf("%s\n", ip);*/
    //printf("please enter a port number\n");
    //int port;
    //scanf("%d", &port);
    // assign IP and Port
    //127.0.0.1
    int port = atoi(argv[2]);
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(port);

    // connect client socket to server socket
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0)
    {
        printf("connection with server failed\n");
        exit(0);
    }
    else
    {
        printf("connected to the server\n");
    }

    // function to initiate chat
    func(sockfd);
    printf("function exited\n");
    // closes the soccket
    sockClose(sockfd);
}