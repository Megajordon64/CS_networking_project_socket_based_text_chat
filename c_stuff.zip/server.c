// created by Jordon Zeigler 3/3/2021
// code referenced from Professor Girard
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifdef _WIN32
  #include <winsock2.h>
  #include <Ws2tcpip.h>
#else
  #include <sys/socket.h>
  #include <arpa/inet.h>
  #include <netdb.h> 
  #include <unistd.h>
#endif
#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>

#ifndef _WIN32
  #define SOCKET int
#endif
#define MAX 10
#define PORT 4446
#define SA struct sockaddr
#define sock
//#define bzero(b,len) (memset((b), '\0', (len)), (void) 0)
#pragma comment(lib, "WS2_32.lib")
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

/*
int sockInit(void)
{
  #ifdef _WIN32
    WSADATA wsa_data;
    return WSAStartup(MAKEWORD(1,1), &wsa_data);
  #else
    return 0;
  #endif
}

int sockQuit(void)
{
  #ifdef _WIN32
    return WSACleanup();
  #else
    return 0;
  #endif
}

int sockClose(sock soc)
{

  int status = 0;

  #ifdef _WIN32
    status = shutdown(soc, SD_BOTH);
    if (status == 0) { status = closesocket(soc); }
  #else
    status = shutdown(soc, SHUT_RDWR);
    if (status == 0) { status = close(soc); }
  #endif

  return status;

}*/

void readFromConnection(int incomingSocket, char* data)
{
    char tmp[MAX+1];
    bzero(tmp,MAX+1);
    int count = 0;
    //printf("right before while\n");

    while (count != MAX)
    {
        int start = count;
        int maxRead = MAX - start;
        //printf("before recv\n");
        count += recv(incomingSocket,tmp,maxRead,0);
        if(count == 0)
        {
          break;
        }
        printf("%d\n", count);
        if (count > start)
        {
           // printf("%s\n", tmp);
        }
        for (int x = start; x < count; x++)
        {
            data[x] = tmp[x-start];
        }
    }
}


// designed for chat between client and server
void * func(void *sockfd)
{
    printf("in func\n");
    //int sock = *(int*)sockfd;
    char buff[MAX+1];
    
    int n;

    while(1){
        
        bzero(buff,MAX+1);
        int s = *(int*)sockfd;
        printf("new: %d\n", s);
        printf("right before connection is read\n");
        readFromConnection(s, buff);
        if(strlen(buff) == 0){
          break;
        }
        //printf("%s\n", buff);
        //read(*(int*)sockfd,buff, 10);
        buff[MAX+1] = '\0';
        /*if(strlen(buff) > MAX+1){
          buff[MAX+1] = '\0';
        }*/

        char *p1 = buff;
        char *p2 = buff + strlen(buff)-1;

        while (p1 < p2) {
            char tmp = *p1;
            *p1++ = *p2;
            *p2-- = tmp;
        }
        //printf("%s\n", buff);
        // sizof(buff) former third parameter
        send(*(int*)sockfd,buff,strlen(buff),0);
    }
    
        //free(sockfd);
    //printf("Exited the loop");
    close(*(int*)sockfd);
    //pthread_exit(NULL);
    time_t t;
    time(&t);
    printf("thread exited: %s", ctime(&t));
    pthread_exit(NULL);
        //send(sockfd, buff, strlen(buff), 0);
    
}

int main(int argc, char * argv[])
{
    int sockfd, connfd, *newfd, len;
    struct sockaddr_in servaddr, client;

    /*#ifdef _WIN32
        sockfd = sockInit();
    #endif*/
    sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (sockfd == -1)
    {
        printf("socket creation failed\n");
        exit(0);
    }
    else
    {
        printf("Socket successfully created\n");
    }

    bzero(&servaddr, sizeof(servaddr));

    /*printf("please enter an IP address\n");
    char ip[16];
    scanf("%15s", ip);
    printf("%s\n", ip);
    printf("please enter a port number\n");
    int port;
    scanf("%d", &port);*/

    // assign IP and PORT
    int port = atol(argv[2]);
    printf("%d", port);
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(port);

    // binding newly created socket to given IP
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0)
    {
        printf("socket bind failed\n");
        exit(0);
    }
    else
    {
        printf("socket successfully binded\n");
    }

    // server is ready to listen and verify
    if ((listen(sockfd, 5)) != 0)
    {
        printf("listen failed, we'll get em next time\n");
        exit(0);
    }
    else
    {
        printf("server is now listening\n");
    }
    len = sizeof(client);

    //while(1){

    while(connfd = accept(sockfd, (SA*)&client, &len))
    {
      if (connfd < 0) 
      {
          printf("server accept failed\n");
          exit(0);
      }
      else
      {
          printf("server has accepted the client\n");
      }



      pthread_t sniffer_thread;
      printf("connfd: %d\n", connfd);
      newfd = malloc(sizeof(connfd));
      *newfd = connfd;
      //printf("newfd: %d\n", newfd);
      

      if( pthread_create( &sniffer_thread , NULL ,  func, newfd) < 0)
        {
            perror("could not create thread");
            return 1;
        }

      //printf("%d\n", connfd);
      //func(connfd);
    }
    // close the server
    close(connfd);
    close(sockfd);
}