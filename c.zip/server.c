#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifdef _WIN32
  #include <winsock2.h>
  #include <Ws2tcpip.h>
#else
  #include <sys/socket.h>
  #include <arpa/inet.h>
  #include <netdb.h> 
  #include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifndef _WIN32
  #define SOCKET int
#endif
#define MAX 10
#define PORT 4446
#define SA struct sockaddr
#define sock
#define bzero(b,len) (memset((b), '\0', (len)), (void) 0)
#pragma comment(lib, "WS2_32.lib")


int sockInit(void)
{
  #ifdef _WIN32
    WSADATA wsa_data;
    return WSAStartup(MAKEWORD(1,1), &wsa_data);
  #else
    return 0;
  #endif
}

int sockQuit(void)
{
  #ifdef _WIN32
    return WSACleanup();
  #else
    return 0;
  #endif
}

int sockClose(sock soc)
{

  int status = 0;

  #ifdef _WIN32
    status = shutdown(soc, SD_BOTH);
    if (status == 0) { status = closesocket(soc); }
  #else
    status = shutdown(soc, SHUT_RDWR);
    if (status == 0) { status = close(soc); }
  #endif

  return status;

}

void readFromConnection(int incomingSocket, char* data)
{
    char tmp[MAX+1];
    bzero(tmp,MAX+1);
    int count = 0;

    while (count != MAX)
    {
        int start = count;
        int maxRead = MAX - start;
        count += recv(incomingSocket,tmp,maxRead,0);
        if (count > start)
        {
           // printf("%s\n", tmp);
        }
        for (int x = start; x < count; x++)
        {
            data[x] = tmp[x-start];
        }
    }
}


// designed for chat between client and server
void func(int sockfd)
{
    char buff[MAX+1];
    
    int n;

    for (n = 0; n<MAX; n++) {
        
        bzero(buff,MAX+1);
        read(sockfd,buff, 10);
        if(strlen(buff) > MAX+1){
          buff[MAX+1] = '\0';
        }

        char *p1 = buff;
        char *p2 = buff + strlen(buff) - 1;

        while (p1 < p2) {
            char tmp = *p1;
            *p1++ = *p2;
            *p2-- = tmp;
        }
        printf("%s\n", buff);
        send(sockfd,buff,sizeof(buff),0);
        
        //send(sockfd, buff, strlen(buff), 0);
    }
}

int main()
{
    int sockfd, connfd, len;
    struct sockaddr_in servaddr, client;

    #ifdef _WIN32
        sockfd = sockInit();
    #endif
        sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (sockfd == -1)
    {
        printf("socket creation failed\n");
        exit(0);
    }
    else
    {
        printf("Socket successfully created\n");
    }

    bzero(&servaddr, sizeof(servaddr));

    // assign IP and PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // binding newly created socket to given IP
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0)
    {
        printf("socket bind failed\n");
        exit(0);
    }
    else
    {
        printf("socket successfully binded\n");
    }

    // server is ready to listen and verify
    if ((listen(sockfd, 5)) != 0)
    {
        printf("listen failed we'll get em next time\n");
        exit(0);
    }
    else
    {
        printf("server is now listening\n");
    }
    len = sizeof(client);

    connfd = accept(sockfd, (SA*)&client, &len);
    if (connfd < 0) 
    {
        printf("server accept failed\n");
        exit(0);
    }
    else
    {
        printf("server has accepted the client\n");
    }

    printf("%d\n", connfd);
    func(connfd);

    // close the server
    sockClose(sockfd);
}