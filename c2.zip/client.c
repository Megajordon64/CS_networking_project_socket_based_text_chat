#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifdef _WIN32
  #include <winsock2.h>
  #include <Ws2tcpip.h>
#else
  #include <sys/socket.h>
  #include <arpa/inet.h>
  #include <netdb.h> 
  #include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma comment(lib, "Ws2_32.lib")

//#include <windows.h>
//#include <winsock2.h>
//#include <ws2tcpip.h>
//#include <iphlpapi.h>
#ifndef _WIN32
  #define SOCKET int
#endif

#define MAX 14
#define PORT 4446
#define SA struct sockaddr
#define sock
#define bzero(b,len) (memset((b), '\0', (len)), (void) 0)


int sockInit(void)
{
  #ifdef _WIN32
    WSADATA wsa_data;
    return WSAStartup(MAKEWORD(1,1), &wsa_data);
  #else
    return 0;
  #endif
}

int sockQuit(void)
{
  #ifdef _WIN32
    return WSACleanup();
  #else
    return 0;
  #endif
}

int sockClose(sock soc)
{

  int status = 0;

  #ifdef _WIN32
    status = shutdown(soc, SD_BOTH);
    if (status == 0) { status = closesocket(soc); }
  #else
    status = shutdown(soc, SHUT_RDWR);
    if (status == 0) { status = close(soc); }
  #endif

  return status;

}

void readFromConnection(int incomingSocket, char* data)
{
    char tmp[MAX+1];
    bzero(tmp,MAX+1);
    int count = 0;

    while (count != MAX)
    {
        int start = count;
        int maxRead = MAX - start;
        count += recv(incomingSocket,tmp,maxRead,0);
        if (count > start)
        {
            printf("%s\n", tmp);
        }
        for (int x = start; x < count; x++)
        {
            data[x] = tmp[x-start];
        }
    }
}

void print_reverse(char* reverse){
  printf("%s\n", reverse);
}
void func(int sockfd)
{
    char buff[MAX];
    int n;
    setbuf(stdout, NULL);
    for (int m = 0; m < 10; m++) {
        bzero(buff, sizeof(buff));
        printf("Enter the string: ");
        n = 0;
        fgets(buff, 11, stdin);
        //scanf("%10s", buff);
        //while ((buff[n++] = getchar()) != '\n' && n <= MAX)
        //{
        //    ;
        //}
        if(strlen(buff) > MAX)
        {
          buff[MAX+1] = '\0';
        }
        printf("Sent: %s\n", buff);
        //printf("sent: %ld\n", strlen(buff));
        send(sockfd, buff, strlen(buff), 0);
        recv(sockfd, buff, MAX+1, 0);
        print_reverse(buff);
        
        

    }
}

int main()
{
    setbuf(stdout, NULL);
    int sockfd, connfd;
    struct sockaddr_in servaddr, client;

    //socket creation
    #ifdef _WIN32
        sockfd = sockInit();
    #endif
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
    
    printf("%d", sockfd);
    if (sockfd == -1) 
    {
        printf("socket creation failed\n");
        exit(0);
    }
    else{
        printf("socket created\n");
    }

    bzero(&servaddr, sizeof(servaddr));

    // assign IP and Port
    //127.0.0.1
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);

    // connect client socket to server socket
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0)
    {
        printf("connection with server failed\n");
        exit(0);
    }
    else
    {
        printf("connected to the server\n");
    }

    // function to initiate chat
    func(sockfd);

    // closes the soccket
    sockClose(sockfd);
}